#ifndef __DETECTAR_PERSONAJES_H__
#define __DETECTAR_PERSONAJES_H__ 

/* 
*Le hace una serie de preguntas al usuario y determina
* un personaje segun sus respuestas
*pre: --
*post: --
*/
void detectar_personaje(char* personaje_detectado);

#endif